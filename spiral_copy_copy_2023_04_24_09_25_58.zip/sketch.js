let x = 600 / 2,
  y = 600 / 2,
  s = 20,
  n = 0,
  r = 0;
let move = 35,
  p = 1,
  stepsize = 1,
  ofsteps = 0;
let nom = 1,
  i = 2;
g=0;
let max=16*16;
function setup() {
  createCanvas(600, 600);
  background(220);
}

function draw() {
  nom += 1;
  rectMode(CENTER);
  strokeWeight(2);
  for (i = 2; i <= nom/2 ; ++i) {
    if (nom%i == 0) {
      r = 225;
      g+=1;
    } else {
      r = 0;
    }
  }
  fill(r, 0, 0);
  if (nom < max) {
    if(nom<max-1){
    if (n == 0) {
      line(x, y, x + move, y);
    }
    if(n==1){line(x, y, x, y+move)}
  
  }
  rect(x, y, s, s);}

  switch (n) {
    case 0:
      x += move;
      ofsteps += 1;
      if (ofsteps == stepsize) {
        ofsteps = 0;
        n = 1;
      }
      break;
    case 1:
      y += move;
      ofsteps += 1;
      if (ofsteps == stepsize) {
        ofsteps = 0;
        n = 2;
      }
      break;
    case 2:
      stepsize += 1;
      ofstep = 0;
      p += 1;
      if (p == 2) {
        move *= -1;
        p = 1;
      }
      n = 0;
      break;
    case 3:
      break;
  }
}
