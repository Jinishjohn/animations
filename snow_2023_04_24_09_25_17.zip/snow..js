function snow(){
  this.x=random(0,width);
  this.y=random(0,-height);
  this.r=random(2,5);
  this.angle=random(0,90);
  if(random(0,1)<0.2){
      this.r=random(5,10);
  }

this.show = function(){
  noStroke();
  fill(0,350,0)
  ellipse(this.x,this.y,this.r);
}

this.update=function(){
  this.y+=(this.r*0.1);
  if(this.y>height){
      this.x=random(0,width);
  this.y=random(0,-height);
  }
  

}
  
this.swing=function(){
  this.x+=0.05*this.r*sin(this.angle);
  this.angle+=4;} 

}