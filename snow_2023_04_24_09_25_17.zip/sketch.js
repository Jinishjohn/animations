let Snow=[];
let i;
let n=450;
function setup() {
  createCanvas(700, 600);
  for(i=0;i<n;i++){
    Snow[i] = new snow();
  }
  
}

function draw() {
  background(0);
   for(i=0;i<n;i++){
  Snow[i].show();
  Snow[i].update();
  Snow[i].swing();
   }
}

