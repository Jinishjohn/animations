function star(){
   this.x = random(0,width);
  this.y=random(0,height);
  this.r=random(3,4);
  this.show=function(){
   noStroke();
  ellipse(this.x,this.y,this.r,this.r);
  }
  this.blink=function(){
      this.r=random(3,5);
    
  }
}