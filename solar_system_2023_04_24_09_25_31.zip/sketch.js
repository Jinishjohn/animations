let x=0;let y=0;
let x1=110;let y1=110;
let x2=30;let y2=30;
let angle=45;let angle1=45;
let Star=[];
function setup() {
  createCanvas(600, 600);
for(let i=0;i<50;i++){
  Star[i]=new star();
}
}

function draw() {
  background(0);
  for(let i=0;i<50;i++){
  Star[i].show();
    Star[i].blink();
}
  push();
  translate(width/2,height/2);
  noStroke();
  fill(255,255,0);
  ellipse(x,y,80,80);
  let d=dist(x,y,x1,y1);
  angleMode(DEGREES);
  y1=cos(angle)*d;
  x1=sin(angle)*d+1;
  fill(0,200,0);
  ellipse(x1,y1,40,40);
  
  angle+=1;
  pop();
  push();
  translate(width/2,height/2);
  translate(x1,y1);
  fill(150);
   let d1=dist(0,0,x2,y2);
  angleMode(DEGREES);
  y2=cos(angle1)*d1;
  x2=sin(angle1)*d1;
  ellipse(x2,y2,10,10);
  angle1+=3;
  pop();
}
